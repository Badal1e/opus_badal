```
# GenAI fraud detection — Streamlit app

Streamlit UI for payment disputes: customers file issues, agents import transactions, run NLP + fraud scoring + LLM summary, approve or reject cases, and optional email (acknowledgement on submit + verdict on decision).

## What you need

- **Python 3.9+** (3.9 is tested with the pinned SpaCy stack)
- This repository cloned or unzipped on your machine

## Setup

### 1. Virtual environment

From the **repository root** (the folder that contains `app/`, `src/`, and `requirements.txt`):

```bash
python3 -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
```

### 2. Install dependencies

```bash
pip install --upgrade pip
pip install -r requirements.txt
```

This installs Streamlit, pandas/scikit-learn, SpaCy + `en_core_web_sm` (via the wheel URL in `requirements.txt`), OpenAI client (for OpenRouter), and optional `yagmail` for SMTP.

### 3. Environment variables

Create a **`.env`** file in the project root (do not commit real keys). Example:

```bash
touch .env
```

| Variable | Purpose |
|----------|---------|
| `OPENROUTER_API_KEY` | Required for LLM summaries (OpenRouter API). |
| `EMAIL_ENABLED` | Set to `false` to skip sending emails. |
| `SMTP_*` | If email is enabled, Gmail (or other SMTP) for registration and verdict notifications. |

### 4. SQLite database

Initialize tables (must run from the **repository root** so `src` is a package):

```bash
python -m src.init_db
```

The DB file is created at `data/disputes.sqlite` (see `src/database.py` and `src/paths.py`).

If present, bundled CSVs are loaded into the `transactions` table:

- `data/raw_transactions.csv`
- `data/GenAI_Payment_Dispute_Dataset_10K.csv`

The app resolves transactions by ID from SQLite, not by reading those CSVs at runtime.

### 5. Run the app

From the **repository root**:

```bash
streamlit run app/main.py
```

Open the URL Streamlit prints (usually `http://localhost:8501`).

**Sidebar navigation:** the app uses a custom menu. In `.streamlit/config.toml`, `showSidebarNavigation = false` hides Streamlit’s duplicate auto page list (needs a recent Streamlit, e.g. 1.33+).

### Deploy on Streamlit Community Cloud

You can host this app on **[Streamlit Community Cloud](https://streamlit.io/cloud)** (free tier available):

1. Push the repo to **GitHub** (keep `.env` out of git; use `.gitignore`).
2. In Cloud, **New app** → pick the repo, branch, and **Main file path**: `app/main.py`.
3. Under **Secrets**, add TOML matching your `.env`, for example:
   ```toml
   OPENROUTER_API_KEY = "your-key"
   EMAIL_ENABLED = "false"
   SMTP_HOST = ""
   SMTP_PORT = "587"
   SMTP_USER = ""
   SMTP_PASSWORD = ""
   ```
4. Deploy. The build uses `requirements.txt`. **Note:** the default SQLite file under `data/` is **ephemeral** on Cloud (resets when the app sleeps or restarts). For production persistence use an external database or object storage; for demos, run `python -m src.init_db` via a one-off job or accept a fresh DB per session.

Secrets are read in code via `st.secrets` where implemented (e.g. LLM key) and `python-dotenv` locally.

## ML and AI stack

The app combines **classical ML** (fast, CPU-friendly, no GPU), **lightweight NLP**, **deterministic rules**, and a **hosted LLM** for prose. Together they cover scoring, categorization, entity extraction, and human-readable summaries.

| Piece | Role | Artifact / entrypoint |
|-------|------|------------------------|
| Fraud risk | Binary-ish risk score + band (High / Medium / Low) | `models/fraud_model.pkl`, `src/fraud_engine.py` |
| Dispute category | Map complaint text → category label | `models/dispute_classifier.pkl`, `src/nlp_processor.py` |
| Entities | Pull money, dates, orgs from text | SpaCy `en_core_web_sm` |
| Narrative | Summary + recommendation for agents | OpenRouter `stepfun/step-3.5-flash:free`, `src/llm_orchestrator.py` |

**How `dispute_category` is used:** On the **fraud** path, the field on the transaction record is a **categorical input** (one-hot encoded). The **dispute classifier** predicts a category from **free-text** when the customer complaint is processed; that prediction is separate from the fraud pipeline’s use of a stored category field.

---

### Fraud model (`fraud_model.pkl`)

**What it is**

- A single scikit-learn **`Pipeline`**: preprocessing + **`RandomForestClassifier`**.
- **Preprocessing** (`ColumnTransformer`):
  - **`StandardScaler`** on numeric **`amount`**.
  - **`TfidfVectorizer`** on **`complaint_description`** (up to 4000 features, unigrams + bigrams, `min_df=1`) so free text is represented as weighted token features without a large neural encoder.
  - **`OneHotEncoder`** (`handle_unknown="ignore"`, up to 50 categories per column) on **`dispute_category`**, **`merchant_name`**, and **`location`** so categorical context is explicit for the tree model.
- **Classifier:** **`RandomForestClassifier`** with `n_estimators=120`, `class_weight="balanced_subsample"`, `random_state=42`, `n_jobs=-1`.

**Training data and labels**

- Data comes from `data/GenAI_Payment_Dispute_Dataset_10K.csv` and/or `data/raw_transactions.csv` (concatenated, deduped by `transaction_id`); if neither exists, a small synthetic CSV is generated first.
- The **target label is not a column in the CSV**: `compute_training_labels()` builds a **binary “fraud risk”** label using heuristics (high-risk dispute categories and large amounts get higher positive rates; other rows use lower rates). That makes the forest learn patterns aligned with **proxy risk** rather than confirmed fraud labels. Treat offline metrics as indicative of this setup, not ground-truth fraud accuracy.

**Why this design**

- **Random forests** handle **mixed data** (numeric + high-dimensional sparse text + many categories) in one pipeline, capture **nonlinear** interactions (e.g. amount × text cues), and give **probability estimates** via `predict_proba` for ranking-style scores.
- **`balanced_subsample`** mitigates **class imbalance** when positives are rarer than negatives.
- **TF-IDF** keeps the stack **simple and portable** (no transformer weights, works on modest hardware).
- At **inference**, `FraudEngine` **blends** the model with **rules** (keyword boosts for “unauthorized” / “duplicate” / “refund”, and amount thresholds) so obvious linguistic and value cues are not wholly dependent on the trained forest. See `src/fraud_engine.py`.

---

### Dispute category classifier (`dispute_classifier.pkl`)

**What it is**

- **Pipeline:** **`TfidfVectorizer`** → **`LogisticRegression`** (multiclass, one-vs-rest under the hood for multinomial with `lbfgs`).
- **Vectorizer:** up to **20,000** features, **(1, 2)-grams**, `min_df=2`, `sublinear_tf=True` (log-scaled term frequencies often help text classification).
- **Classifier:** `max_iter=2000`, `class_weight="balanced"`, `solver="lbfgs"`, `random_state=42`.
- Trained on **`data/GenAI_Payment_Dispute_Dataset_10K.csv`**: columns **Complaint Description** (text) and **Dispute Category** (label). Train/test split **80/20**, stratified.

**Why this design**

- **Logistic regression on TF-IDF** is a strong baseline for **multiclass text classification**: fast to train and infer, works well on sparse bag-of-ngrams, and stays **interpretable** — the project uses **coefficient × TF-IDF** contributions in `explain_prediction()` to show top token evidence for the predicted class.
- **`class_weight="balanced"`** reduces bias toward frequent dispute categories.
- **Scam / phishing** wording is handled **before** the ML model: keyword rules in `src/nlp_processor.py` assign **“Scam / Phishing”** when cues like phishing, OTP abuse, or impersonation appear, because those labels may be sparse or missing in the training taxonomy. If the ML path fails, a **keyword fallback** list is used.

---

### SpaCy (`en_core_web_sm`)

**What it is**

- The small English pipeline **`en_core_web_sm`** loads once and runs **named-entity recognition** over the complaint.

**Why it is used**

- It extracts **MONEY**, **DATE**, and **ORG** spans for the UI and downstream context without calling an LLM. The small model keeps **dependencies and memory** reasonable for a Streamlit demo.

---

### LLM (OpenRouter — `stepfun/step-3.5-flash:free`)

**What it is**

- The OpenAI-compatible client points at **OpenRouter**; chat completions use **`stepfun/step-3.5-flash:free`** with **temperature 0.3** (`src/llm_orchestrator.py`).
- The prompt includes transaction fields, NLP classification, fraud score/risk, and the raw complaint so the model writes an **investigation summary** and **recommendation** in natural language.

**Why it is used**

- A **generative** model is appropriate for **fluent, variable-length** explanations and suggested next steps; tabular ML does not produce that prose.
- A **flash**-style model keeps **latency and cost** lower than large reasoning models; the **free** route matches demo and teaching use (availability and quotas depend on OpenRouter).

**Caveat:** LLM output should be reviewed in production; it is **not** the authoritative fraud label.

---

### Optional: retrain models manually

From the **repository root**, with the venv activated:

```bash
python models/train_fraud_model.py
python models/train_dispute_classifier.py
```

## Project layout (short)

| Path | Role |
|------|------|
| `app/main.py` | Home |
| `app/pages/` | Customer portal, agent dashboard, case status (`login.py`) |
| `app/ui_theme.py` | Shared CSS + sidebar |
| `src/` | DB, ingestion, NLP, fraud engine, LLM, email, CSV sync |
| `data/` | SQLite DB, bundled CSVs, `generate_data.py` |
| `models/` | `train_fraud_model.py`, `train_dispute_classifier.py`, trained `.pkl` artifacts |
| `tests/` | Unit tests |

## Optional: regenerate sample transactions

If you use the bundled generator:

```bash
python -m data.generate_data
```

(Module name is `data.generate_data`, not `generate_data.py`.)

## Troubleshooting

- **Import / path errors:** Always run `streamlit run app/main.py` from the project root so `app` and `src` resolve correctly.
- **Database init:** Use `python -m src.init_db` from the project root (not `python init_db.py` inside `src/` alone — package imports require the module form).
- **SpaCy model:** Reinstall with `pip install -r requirements.txt` if `en_core_web_sm` is missing.
- **LLM errors:** Confirm `OPENROUTER_API_KEY` in `.env` and network access to OpenRouter.

## Zip of the source

A distributable archive can exclude the virtualenv and caches, for example:

```bash
zip -r project.zip . \
  -x "*.venv/*" -x "*__pycache__/*" -x "*.pyc" -x ".git/*" -x "*/.env"
```

Keep your real `.env` out of the zip; document variables using the table above.

```