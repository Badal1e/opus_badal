import psycopg2

# URL-encode your password: '@' -> '%40'
DB_URL = "postgresql://postgres:Abhse1278%40%40340@db.pmlmicnemljmbevfnpmo.supabase.co:5432/postgres"

# Supabase requires SSL
conn = psycopg2.connect(DB_URL, sslmode="require")

cur = conn.cursor()
cur.execute("SELECT NOW();")
print(cur.fetchone())

cur.close()
conn.close()