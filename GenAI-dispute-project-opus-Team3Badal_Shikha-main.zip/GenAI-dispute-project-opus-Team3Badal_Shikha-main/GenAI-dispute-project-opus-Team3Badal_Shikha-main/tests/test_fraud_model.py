"""Genuine test cases for the fraud pipeline + FraudEngine (run from repo root)."""
import sys
import unittest
from pathlib import Path

_ROOT = Path(__file__).resolve().parent.parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

import joblib
import pandas as pd
from sklearn.pipeline import Pipeline

from src.fraud_engine import FraudEngine
from src.paths import models_path


def _ensure_model():
    p = models_path("fraud_model.pkl")
    if not p.exists():
        from models.train_fraud_model import train_model

        train_model()


class TestFraudPipeline(unittest.TestCase):
    """2–3 end-to-end checks that the saved model + engine behave sensibly."""

    @classmethod
    def setUpClass(cls):
        _ensure_model()

    def test_1_pipeline_loads_and_predicts_without_error(self):
        """Saved artifact is a Pipeline; single-row predict + predict_proba succeed."""
        path = models_path("fraud_model.pkl")
        self.assertTrue(path.exists(), "models/fraud_model.pkl missing")
        model = joblib.load(str(path))
        self.assertIsInstance(model, Pipeline)
        X = pd.DataFrame(
            [
                {
                    "amount": 100.0,
                    "complaint_description": "duplicate charge on my card",
                    "dispute_category": "duplicate charge",
                    "merchant_name": "unknown",
                    "location": "unknown",
                }
            ]
        )
        pred = model.predict(X)
        proba = model.predict_proba(X)
        self.assertEqual(pred.shape, (1,))
        self.assertEqual(proba.shape, (1, 2))

    def test_2_fraud_engine_output_shape_and_types(self):
        """FraudEngine returns the same contract the app expects."""
        engine = FraudEngine()
        txn = {
            "transaction_id": "TEST-TXN-001",
            "amount": 250.0,
            "merchant_name": "unknown",
            "location": "unknown",
            "dispute_category": "product/service not received",
        }
        out = engine.predict(txn, "package never arrived", case_id=None)
        self.assertIn("fraud_score", out)
        self.assertIn("risk_level", out)
        self.assertIn("fraud_indicators", out)
        self.assertIsInstance(out["fraud_score"], (int, float))
        self.assertIn(out["risk_level"], ("Low", "Medium", "High"))

    def test_3_high_risk_case_scores_above_benign_case(self):
        """
        Genuine behavioral check: clear fraud-like dispute + high amount vs
        small routine-looking case — final score should rank appropriately.
        """
        engine = FraudEngine()
        high = {
            "transaction_id": "TEST-HIGH",
            "amount": 45000.0,
            "merchant_name": "unknown",
            "location": "unknown",
            "dispute_category": "unauthorized transaction",
            "complaint_description": "someone stole my card",
        }
        low = {
            "transaction_id": "TEST-LOW",
            "amount": 12.5,
            "merchant_name": "cafe",
            "location": "local",
            "dispute_category": "",
            "complaint_description": "",
        }
        r_high = engine.predict(
            high,
            "this charge is not mine unauthorized fraud",
            case_id=None,
        )
        r_low = engine.predict(low, "question about my statement", case_id=None)
        self.assertGreater(
            r_high["fraud_score"],
            r_low["fraud_score"],
            "Expected high-risk scenario to score above benign scenario",
        )


if __name__ == "__main__":
    unittest.main()
