"""Dispute classifier: TF-IDF + LR trained on GenAI 10K CSV."""
import sys
import unittest
from pathlib import Path

_ROOT = Path(__file__).resolve().parent.parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

from src.nlp_processor import NLPProcessor


class TestDisputeClassifierML(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        nlp = NLPProcessor()
        nlp._ensure_dispute_model()

    def test_unauthorized_phrasing_cross_border(self):
        """Phrasing similar to TXN1009 — should map to Unauthorized (learned from data)."""
        nlp = NLPProcessor()
        out = nlp.process(
            "This transaction happened in another country while I am in India."
        )
        self.assertEqual(out["classification"], "Unauthorized Transaction")
        self.assertIn("classification_confidence", out)
        self.assertGreater(out["classification_confidence"], 0.4)
        self.assertTrue(out.get("classification_evidence"))

    def test_duplicate_charge_wording(self):
        nlp = NLPProcessor()
        out = nlp.process(
            "I was charged twice for the same order on the same day. Please refund the duplicate."
        )
        self.assertEqual(out["classification"], "Duplicate Charge")


if __name__ == "__main__":
    unittest.main()
