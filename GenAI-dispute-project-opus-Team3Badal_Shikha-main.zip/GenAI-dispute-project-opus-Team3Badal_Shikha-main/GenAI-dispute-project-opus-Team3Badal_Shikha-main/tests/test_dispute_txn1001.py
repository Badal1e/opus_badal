"""Scenario: TXN1001-style complaint should classify as Unauthorized Transaction (NLP)."""
import sys
import unittest
from pathlib import Path

_ROOT = Path(__file__).resolve().parent.parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

from src.fraud_engine import FraudEngine
from src.nlp_processor import NLPProcessor


COMPLAINT_TXN1001 = (
    'I did not make this transaction. I was not in Mumbai and my card was used without my permission.'
)

TXN_ROW = {
    "transaction_id": "TXN1001",
    "customer_id": "CUST501",
    "amount": 18500.0,
    "merchant_name": "unknown",
    "location": "unknown",
    "date_time": "2026-03-20",
    "complaint_description": COMPLAINT_TXN1001,
    "dispute_category": "",
}


class TestTXN1001Scenario(unittest.TestCase):
    def test_nlp_classifies_unauthorized_transaction(self):
        nlp = NLPProcessor()
        out = nlp.process(COMPLAINT_TXN1001)
        self.assertEqual(
            out["classification"],
            "Unauthorized Transaction",
            msg=f"Expected NLP dispute class; got {out!r}",
        )

    def test_fraud_engine_returns_high_risk_for_same_context(self):
        """Amount + complaint triggers elevated fraud score (hybrid engine)."""
        engine = FraudEngine()
        r = engine.predict(TXN_ROW, COMPLAINT_TXN1001, case_id=None)
        self.assertIn(r["risk_level"], ("Medium", "High"))
        self.assertGreaterEqual(r["fraud_score"], 0.4)


if __name__ == "__main__":
    unittest.main()
