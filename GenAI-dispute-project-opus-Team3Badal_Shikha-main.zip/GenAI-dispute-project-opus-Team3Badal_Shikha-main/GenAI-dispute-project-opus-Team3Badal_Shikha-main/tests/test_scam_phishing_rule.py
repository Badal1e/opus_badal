import sys
import unittest
from pathlib import Path

_ROOT = Path(__file__).resolve().parent.parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

from src.nlp_processor import NLPProcessor


class TestScamPhishingRule(unittest.TestCase):
    def test_otp_bank_pretend_returns_scam_phishing(self):
        text = (
            "I received a call pretending to be from bank support and was tricked into sharing OTP. "
            "Money got deducted."
        )
        out = NLPProcessor().process(text)
        self.assertEqual(out["classification"], "Scam / Phishing")
        self.assertEqual(out.get("classification_confidence"), 1.0)
        self.assertIn("scam_phishing", out.get("fraud_indicators", []))


if __name__ == "__main__":
    unittest.main()
