import sys
from pathlib import Path

_ROOT = Path(__file__).resolve().parent.parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

import joblib
import numpy as np
import pandas as pd

from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from src.csv_import import normalize_and_clean
from src.paths import data_path, models_dir, models_path

_FEATURE_COLS = [
    "amount",
    "complaint_description",
    "dispute_category",
    "merchant_name",
    "location",
]

_HIGH_RISK_CATEGORIES = frozenset(
    {
        "unauthorized transaction",
        "duplicate charge",
        "wrong amount",
        "subscription issue",
    }
)


def clean_dataset(df: pd.DataFrame) -> pd.DataFrame:
    """Training entry: normalized + cleaned dataframe."""
    return normalize_and_clean(df)


def run_eda(df: pd.DataFrame) -> None:
    print("\n========================")
    print("📊 EDA REPORT")
    print("========================")
    print("\n➡ Shape:", df.shape)
    print("\n➡ Missing Values:\n", df.isnull().sum())
    print("\n➡ Descriptive Statistics:\n", df.describe(include="all"))
    print("\n========================\n")


def compute_training_labels(df: pd.DataFrame) -> np.ndarray:
    """
    Binary fraud label: use dispute when present; else synthetic amount-based.
    """
    rng = np.random.RandomState(42)
    y = np.zeros(len(df), dtype=int)
    for i in range(len(df)):
        cat = str(df.iloc[i].get("dispute_category") or "").strip().lower()
        amt = float(df.iloc[i]["amount"])
        if cat in _HIGH_RISK_CATEGORIES:
            y[i] = 1 if rng.random() < 0.82 else 0
        elif cat:
            y[i] = 1 if rng.random() < 0.11 else 0
        else:
            if amt > 10000:
                y[i] = 1 if rng.random() < 0.80 else 0
            else:
                y[i] = 1 if rng.random() < 0.10 else 0
    return y


def evaluate(name: str, model: Pipeline, X_val: pd.DataFrame, y_val: np.ndarray) -> dict:
    y_pred = model.predict(X_val)
    if hasattr(model, "predict_proba"):
        y_proba = model.predict_proba(X_val)[:, 1]
    else:
        y_scores = model.decision_function(X_val)
        y_proba = (y_scores - y_scores.min()) / (y_scores.max() - y_scores.min() + 1e-12)

    acc = accuracy_score(y_val, y_pred)
    prec = precision_score(y_val, y_pred, zero_division=0)
    rec = recall_score(y_val, y_pred, zero_division=0)
    f1 = f1_score(y_val, y_pred, zero_division=0)
    try:
        auc = roc_auc_score(y_val, y_proba)
    except ValueError:
        auc = 0.0

    print(f"\n📌 {name} RESULTS")
    print("---------------------------")
    print(f"Accuracy : {acc:.4f}")
    print(f"Precision: {prec:.4f}")
    print(f"Recall   : {rec:.4f}")
    print(f"F1 Score : {f1:.4f}")
    print(f"AUC Score: {auc:.4f}")
    print("\nConfusion Matrix:\n", confusion_matrix(y_val, y_pred))

    return {"accuracy": acc, "precision": prec, "recall": rec, "f1": f1, "auc": auc}


def _make_one_hot_encoder() -> OneHotEncoder:
    try:
        return OneHotEncoder(handle_unknown="ignore", sparse_output=False, max_categories=50)
    except TypeError:
        return OneHotEncoder(handle_unknown="ignore", sparse=False)


def build_fraud_pipeline() -> Pipeline:
    ohe = _make_one_hot_encoder()
    preprocessor = ColumnTransformer(
        transformers=[
            ("num", StandardScaler(), ["amount"]),
            (
                "txt",
                TfidfVectorizer(max_features=4000, min_df=1, ngram_range=(1, 2)),
                "complaint_description",
            ),
            ("ohe_dc", ohe, ["dispute_category"]),
            ("ohe_m", _make_one_hot_encoder(), ["merchant_name"]),
            ("ohe_l", _make_one_hot_encoder(), ["location"]),
        ],
        remainder="drop",
    )
    clf = RandomForestClassifier(
        random_state=42,
        n_estimators=120,
        class_weight="balanced_subsample",
        n_jobs=-1,
    )
    return Pipeline([("prep", preprocessor), ("clf", clf)])


def train_all(df: pd.DataFrame) -> dict:
    df = clean_dataset(df)
    if df.empty:
        raise ValueError("No rows to train on.")
    run_eda(df)

    for c in _FEATURE_COLS:
        if c not in df.columns:
            df[c] = 0.0 if c == "amount" else ""
    df["amount"] = pd.to_numeric(df["amount"], errors="coerce").fillna(df["amount"].median())
    df["complaint_description"] = df["complaint_description"].fillna("").astype(str)
    df["dispute_category"] = df["dispute_category"].fillna("").astype(str)
    df["merchant_name"] = df["merchant_name"].fillna("unknown").astype(str)
    df["location"] = df["location"].fillna("unknown").astype(str)

    X = df[_FEATURE_COLS].copy()
    y = compute_training_labels(df)

    try:
        X_train, X_val, y_train, y_val = train_test_split(
            X, y, test_size=0.25, random_state=42, stratify=y
        )
    except ValueError:
        X_train, X_val, y_train, y_val = train_test_split(
            X, y, test_size=0.25, random_state=42
        )

    pipe = build_fraud_pipeline()
    pipe.fit(X_train, y_train)
    results = evaluate("Fraud pipeline (RF)", pipe, X_val, y_val)

    models_dir().mkdir(parents=True, exist_ok=True)
    joblib.dump(pipe, str(models_path("fraud_model.pkl")))

    return {"pipeline": results, "best": "Fraud pipeline (RF)"}


def load_training_dataframe() -> pd.DataFrame:
    frames = []
    for fname in (
        "GenAI_Payment_Dispute_Dataset_10K.csv",
        "raw_transactions.csv",
    ):
        p = data_path(fname)
        if p.exists():
            raw = pd.read_csv(p)
            frames.append(normalize_and_clean(raw))
    if not frames:
        from data.generate_data import generate_dataset

        generate_dataset(500)
        raw = pd.read_csv(data_path("raw_transactions.csv"))
        frames.append(normalize_and_clean(raw))
    out = pd.concat(frames, ignore_index=True)
    out = out.drop_duplicates(subset=["transaction_id"], keep="first")
    return out


def train_model() -> None:
    """Train from bundled CSV(s) and write models/fraud_model.pkl (full sklearn Pipeline)."""
    df = load_training_dataframe()
    train_all(df)


def train_from_dataframe(df: pd.DataFrame) -> dict:
    return train_all(df)


if __name__ == "__main__":
    train_model()
    print("\n🎉 TRAINING DONE!")
