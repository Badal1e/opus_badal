import sys
from pathlib import Path

_ROOT = Path(__file__).resolve().parent.parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

import joblib
import numpy as np
import pandas as pd

# ✅ Force pandas to avoid pyarrow issues
# pd.options.mode.dtype_backend = "numpy_nullable"

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline

from src.paths import data_path, models_dir, models_path

DATA_FILE = "GenAI_Payment_Dispute_Dataset_10K.csv"
MODEL_FILE = "dispute_classifier.pkl"


def load_training_data() -> tuple:
    path = data_path(DATA_FILE)
    if not path.exists():
        raise FileNotFoundError(f"Missing {path}")

    df = pd.read_csv(path)

    if "Complaint Description" not in df.columns or "Dispute Category" not in df.columns:
        raise ValueError("CSV must have Complaint Description and Dispute Category")

    texts = df["Complaint Description"].fillna("").astype(str).str.strip()
    y = df["Dispute Category"].fillna("").astype(str).str.strip()

    # Remove empty rows
    mask = (texts.str.len() > 0) & (y.str.len() > 0)
    texts = texts[mask]
    y = y[mask]

    # ✅ FIX: Convert to NumPy arrays (avoids PyArrow issue)
    return texts.to_numpy(), y.to_numpy()


def build_pipeline() -> Pipeline:
    return Pipeline(
        [
            (
                "tfidf",
                TfidfVectorizer(
                    max_features=20000,
                    ngram_range=(1, 2),
                    min_df=2,
                    sublinear_tf=True,
                ),
            ),
            (
                "clf",
                LogisticRegression(
                    max_iter=2000,
                    class_weight="balanced",
                    solver="lbfgs",
                    random_state=42,
                ),
            ),
        ]
    )


def train_and_save() -> dict:
    X, y = load_training_data()

    # Optional debug
    print("Data types:", type(X), type(y))
    print("Sample size:", len(X))

    X_train, X_test, y_train, y_test = train_test_split(
        X,
        y,
        test_size=0.2,
        random_state=42,
        stratify=y,
    )

    pipe = build_pipeline()
    pipe.fit(X_train, y_train)

    y_pred = pipe.predict(X_test)

    report = classification_report(y_test, y_pred, zero_division=0)
    print("\nClassification Report:\n")
    print(report)

    models_dir().mkdir(parents=True, exist_ok=True)
    out = models_path(MODEL_FILE)

    joblib.dump(pipe, str(out))
    print(f"\n✅ Model saved at: {out}")

    return {"path": str(out), "report": report}


def explain_prediction(pipeline: Pipeline, text: str, top_n: int = 5) -> list:
    """
    Linear model explanation using feature contributions.
    """
    if not (text or "").strip():
        return []

    tfidf = pipeline.named_steps["tfidf"]
    clf = pipeline.named_steps["clf"]

    X = tfidf.transform([text])
    pred = clf.predict(X)[0]

    classes = list(clf.classes_)
    class_idx = classes.index(pred)

    coef_row = clf.coef_[class_idx]
    contrib = X.multiply(coef_row)

    arr = np.asarray(contrib.todense()).ravel()
    names = tfidf.get_feature_names_out()

    order = np.argsort(np.abs(arr))[-top_n:][::-1]

    return [(names[i], float(arr[i])) for i in order if arr[i] != 0]


if __name__ == "__main__":
    train_and_save()