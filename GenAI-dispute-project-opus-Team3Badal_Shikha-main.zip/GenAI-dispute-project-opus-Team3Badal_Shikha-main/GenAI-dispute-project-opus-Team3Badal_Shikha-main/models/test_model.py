import joblib
from src.paths import models_path
from models.train_dispute_classifier import explain_prediction

MODEL_FILE = "dispute_classifier.pkl"


def load_model():
    path = models_path(MODEL_FILE)
    return joblib.load(path)


if __name__ == "__main__":
    model = load_model()

    while True:
        try:
            text = input("\nEnter complaint (or 'exit'): ")

            if text.lower() == "exit":
                print("👋 Exiting...")
                break

            if not text.strip():
                print("⚠️ Please enter some text")
                continue

            # ✅ Prediction
            pred = model.predict([text])[0]

            # ✅ Confidence calculation
            probs = model.predict_proba([text])[0]
            confidence = max(probs)

            print(f"\n📊 Confidence: {confidence:.2f}")

            # ✅ Confidence check
            if confidence < 0.5:
                print("👉 Not confident (unclear complaint)")
            else:
                print(f"👉 Prediction: {pred}")

            # ✅ Explanation
            explanation = explain_prediction(model, text)

            print("🔍 Why?")
            for word, score in explanation:
                print(f"   {word}: {score:.4f}")

        except KeyboardInterrupt:
            print("\n👋 Interrupted. Exiting...")
            break

        except Exception as e:
            print(f"❌ Error: {e}")