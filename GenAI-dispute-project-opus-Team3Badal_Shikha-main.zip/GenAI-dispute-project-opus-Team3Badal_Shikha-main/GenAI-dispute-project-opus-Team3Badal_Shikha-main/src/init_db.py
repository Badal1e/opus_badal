from .database import Database
from .sync_raw_csv import sync_all_bundled_csvs

if __name__ == "__main__":
    db = Database()
    db.initialize()
    n = sync_all_bundled_csvs(db)
    if n:
        print(
            f"Database initialized successfully. Loaded {n} row insert attempt(s) from bundled CSV(s) "
            "(raw_transactions.csv and/or GenAI_Payment_Dispute_Dataset_10K.csv)."
        )
    else:
        print(
            "Database initialized successfully. "
            "(No bundled CSVs or files empty — add CSV or run: python -m data.generate_data)"
        )