import sys
from pathlib import Path
from typing import Optional

import joblib
import numpy as np
import spacy

_PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

from src.paths import models_path

nlp = spacy.load("en_core_web_sm")

_DISPUTE_MODEL = "dispute_classifier.pkl"

# Not present in GenAI 10K labels — catch with rules before ML so OTP/vishing maps correctly.
_SCAM_PHISHING_LABEL = "Scam / Phishing"
_SCAM_PHISHING_NEEDLES = (
    "phishing",
    "vishing",
    "smishing",
    "social engineering",
    "pretending to be",
    "fake bank",
    "fraudulent call",
    "spoofed",
    "scam call",
    "sms scam",
    "tricked into sharing",
    "tricked into",
    "sharing otp",
    "shared otp",
    "gave otp",
    "disclosed otp",
    "otp scam",
    "fake support",
    "impersonat",
)


class NLPProcessor:
    def __init__(self):
        self.dispute_keywords = {
            "did not make this transaction": "Unauthorized Transaction",
            "without my permission": "Unauthorized Transaction",
            "card was used without": "Unauthorized Transaction",
            "did not authorize": "Unauthorized Transaction",
            "not authorize": "Unauthorized Transaction",
            "unauthorized": "Unauthorized Transaction",
            "fraud": "Unauthorized Transaction",
            "duplicate": "Duplicate Charge",
            "charged twice": "Duplicate Charge",
            "twice": "Duplicate Charge",
            "subscription": "Subscription Issue",
            "recurring": "Subscription Issue",
            "merchant": "Merchant Billing Error",
        }
        self._dispute_pipeline = None

    def _match_scam_phishing(self, text: str) -> Optional[str]:
        """Return first matched cue substring, or None."""
        tl = text.lower()
        for needle in _SCAM_PHISHING_NEEDLES:
            if needle in tl:
                return needle
        return None

    def _ensure_dispute_model(self):
        if self._dispute_pipeline is not None:
            return
        path = models_path(_DISPUTE_MODEL)
        if not path.exists():
            from models.train_dispute_classifier import train_and_save

            train_and_save()
        self._dispute_pipeline = joblib.load(str(models_path(_DISPUTE_MODEL)))

    def _keyword_classify(self, text: str) -> str:
        text_lower = text.lower()
        for keyword, label in self.dispute_keywords.items():
            if keyword in text_lower:
                return label
        return "Unknown"

    def extract_entities(self, text: str):
        doc = nlp(text)

        entities = {
            "amounts": [],
            "dates": [],
            "organizations": [],
        }

        for ent in doc.ents:
            if ent.label_ == "MONEY":
                entities["amounts"].append(ent.text)
            elif ent.label_ == "DATE":
                entities["dates"].append(ent.text)
            elif ent.label_ == "ORG":
                entities["organizations"].append(ent.text)

        return entities

    def classify_dispute(self, text: str) -> str:
        return self.process(text)["classification"]

    def process(self, text: str):
        text = (text or "").strip()
        entities = self.extract_entities(text) if text else {"amounts": [], "dates": [], "organizations": []}

        classification = "Unknown"
        confidence = None
        evidence = []

        if text:
            scam_hit = self._match_scam_phishing(text)
            if scam_hit:
                classification = _SCAM_PHISHING_LABEL
                confidence = 1.0
                evidence = [(f"rule:{scam_hit}", 1.0)]
            else:
                try:
                    self._ensure_dispute_model()
                    pipe = self._dispute_pipeline
                    classification = str(pipe.predict([text])[0])
                    proba = pipe.predict_proba([text])[0]
                    confidence = float(np.max(proba))
                    from models.train_dispute_classifier import explain_prediction

                    evidence = explain_prediction(pipe, text, top_n=5)
                except Exception:
                    classification = self._keyword_classify(text)

        fraud_indicators = []
        tl = text.lower()
        if classification == _SCAM_PHISHING_LABEL:
            fraud_indicators.append("scam_phishing")
        if "unauthorized" in tl or "fraud" in tl:
            fraud_indicators.append("suspicious_transaction")
        if "not recognize" in tl:
            fraud_indicators.append("unknown_merchant")

        out = {
            "classification": classification,
            "entities": entities,
            "fraud_indicators": fraud_indicators,
        }
        if confidence is not None:
            out["classification_confidence"] = confidence
        if evidence:
            out["classification_evidence"] = evidence
        return out
