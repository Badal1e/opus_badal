"""CSV column mapping, normalization, and validation for transaction uploads."""
from __future__ import annotations

from typing import Any, Dict, List, Tuple

import pandas as pd

_CANON_TO_INTERNAL: Dict[str, str] = {
    "transaction_id": "transaction_id",
    "customer_id": "customer_id",
    "amount": "amount",
    "transaction_amount": "amount",
    "merchant_name": "merchant_name",
    "location": "location",
    "date_time": "date_time",
    "transaction_date": "date_time",
    "complaint_description": "complaint_description",
    "dispute_category": "dispute_category",
}

_INTERNAL_ORDER: List[str] = [
    "transaction_id",
    "customer_id",
    "amount",
    "merchant_name",
    "location",
    "date_time",
    "complaint_description",
    "dispute_category",
]


def _canon_header(name: str) -> str:
    return str(name).strip().lower().replace(" ", "_")


def _rename_columns_to_internal(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    new_cols: Dict[str, str] = {}
    for c in out.columns:
        canon = _canon_header(c)
        internal = _CANON_TO_INTERNAL.get(canon, canon)
        new_cols[c] = internal
    out = out.rename(columns=new_cols)
    return out


def normalize_transactions_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    """Map old or new CSV headers to internal names; add missing columns with defaults."""
    if df is None or df.empty:
        return pd.DataFrame(columns=_INTERNAL_ORDER)
    out = _rename_columns_to_internal(df)
    for col in _INTERNAL_ORDER:
        if col not in out.columns:
            out[col] = ""
    extra = [c for c in out.columns if c not in _INTERNAL_ORDER]
    out = out[_INTERNAL_ORDER + extra]
    # Defaults per backward-compat rules
    out["merchant_name"] = out["merchant_name"].replace("", pd.NA).fillna("")
    out["location"] = out["location"].replace("", pd.NA).fillna("")
    m = out["merchant_name"].astype(str).str.strip()
    l = out["location"].astype(str).str.strip()
    out["merchant_name"] = m.where(m != "", "unknown")
    out["location"] = l.where(l != "", "unknown")
    for text_col in ("complaint_description", "dispute_category"):
        out[text_col] = out[text_col].fillna("").astype(str)
    out["customer_id"] = out["customer_id"].fillna("").astype(str)
    out["date_time"] = out["date_time"].fillna("").astype(str)
    out["transaction_id"] = out["transaction_id"].fillna("").astype(str)
    return out


def clean_transactions_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    """Numeric amount, text normalization, dates — expects normalized column names."""
    out = df.copy()
    if out.empty:
        return out
    out["amount"] = pd.to_numeric(out["amount"], errors="coerce")
    med = out["amount"].median()
    if pd.isna(med):
        med = 0.0
    out["amount"] = out["amount"].fillna(med)
    desc = out["complaint_description"].fillna("").astype(str).str.lower().str.strip()
    out["complaint_description"] = desc
    cat = out["dispute_category"].fillna("").astype(str).str.strip().str.lower()
    out["dispute_category"] = cat
    raw_dt = out["date_time"].fillna("").astype(str).str.strip()
    raw_dt = raw_dt.replace(r"^(nan|NaT|None)$", "", regex=True)
    parsed = pd.to_datetime(raw_dt, errors="coerce")
    out["date_time"] = ""
    ok = parsed.notna()
    out.loc[ok, "date_time"] = parsed[ok].dt.strftime("%Y-%m-%d %H:%M:%S")
    out["transaction_id"] = out["transaction_id"].astype(str).str.strip()
    out["customer_id"] = out["customer_id"].replace("nan", "").astype(str).str.strip()
    out["merchant_name"] = out["merchant_name"].fillna("unknown").astype(str).str.strip()
    out["location"] = out["location"].fillna("unknown").astype(str).str.strip()
    m2 = out["merchant_name"].replace("", "unknown")
    l2 = out["location"].replace("", "unknown")
    out["merchant_name"] = m2
    out["location"] = l2
    return out


def normalize_and_clean(df: pd.DataFrame) -> pd.DataFrame:
    return clean_transactions_dataframe(normalize_transactions_dataframe(df))


def validate_transaction_csv_df(df: pd.DataFrame) -> Tuple[bool, str]:
    """
    Accept both OLD and NEW column naming; validate after logical mapping.
    Requires at least transaction_id and a coercible amount per row (checked on import loop).
    """
    if df is None or df.empty:
        return False, "CSV has no data rows."
    norm = normalize_transactions_dataframe(df)
    if "transaction_id" not in norm.columns:
        return False, "Could not resolve a transaction ID column."
    if "amount" not in norm.columns:
        return False, "Could not resolve an amount column."
    return True, ""


def row_to_transaction_dict(row: Any) -> Dict[str, Any]:
    """Build DB insert dict from a normalized cleaned row (Series or dict)."""
    if isinstance(row, pd.Series):
        r = row
    else:
        r = pd.Series(row)
    amt = pd.to_numeric(r.get("amount"), errors="coerce")
    if pd.isna(amt):
        amt = 0.0
    else:
        amt = float(amt)
    cid = r.get("customer_id")
    if cid is None or (isinstance(cid, float) and pd.isna(cid)):
        cid = None
    else:
        cid = str(cid).strip() or None
    return {
        "transaction_id": str(r.get("transaction_id", "")).strip(),
        "customer_id": cid,
        "amount": amt,
        "merchant_name": str(r.get("merchant_name") or "unknown").strip() or "unknown",
        "location": str(r.get("location") or "unknown").strip() or "unknown",
        "date_time": str(r.get("date_time") or ""),
        "complaint_description": str(r.get("complaint_description") or ""),
        "dispute_category": str(r.get("dispute_category") or ""),
    }
