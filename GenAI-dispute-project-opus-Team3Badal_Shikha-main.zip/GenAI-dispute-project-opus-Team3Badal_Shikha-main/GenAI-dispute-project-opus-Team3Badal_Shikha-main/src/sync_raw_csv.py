"""Load CSV files into the transactions table (SQLite)."""
from pathlib import Path
from typing import Optional

import pandas as pd

from .csv_import import normalize_and_clean, row_to_transaction_dict
from .database import Database
from .paths import data_path


def sync_transactions_from_csv_path(db: Database, path: Path) -> int:
    """
    Upsert rows from a CSV using INSERT OR IGNORE per transaction_id.
    Accepts OLD or NEW column naming (see csv_import.normalize_transactions_dataframe).
    """
    if not path.exists():
        return 0
    df = pd.read_csv(path)
    df = normalize_and_clean(df)
    n = 0
    for _, row in df.iterrows():
        d = row_to_transaction_dict(row)
        tid = d.get("transaction_id") or ""
        if not tid:
            continue
        db.insert_transaction(d)
        n += 1
    return n


def sync_raw_transactions_csv(db: Optional[Database] = None) -> int:
    """Load data/raw_transactions.csv if present."""
    return sync_transactions_from_csv_path(db or Database(), data_path("raw_transactions.csv"))


def sync_genai_dispute_dataset_csv(db: Optional[Database] = None) -> int:
    """Load GenAI_Payment_Dispute_Dataset_10K.csv if present."""
    return sync_transactions_from_csv_path(
        db or Database(),
        data_path("GenAI_Payment_Dispute_Dataset_10K.csv"),
    )


def sync_all_bundled_csvs(db: Optional[Database] = None) -> int:
    """Load raw_transactions.csv and the GenAI 10K dataset when files exist."""
    db = db or Database()
    return sync_raw_transactions_csv(db) + sync_genai_dispute_dataset_csv(db)
