import sys
from pathlib import Path

_ROOT = Path(__file__).resolve().parent.parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

import pandas as pd

from src.csv_import import normalize_and_clean, row_to_transaction_dict
from src.database import Database
from src.paths import data_path

db = Database()

df = pd.read_csv(data_path("raw_transactions.csv"))
df = normalize_and_clean(df)

for _, row in df.iterrows():
    d = row_to_transaction_dict(row)
    if not d.get("transaction_id"):
        continue
    db.insert_transaction(d)

print("Data inserted into database.")
